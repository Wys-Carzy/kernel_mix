#!/system/bin/sh
# CUSTOM ANIMATION SPEED

# Set speed to 0.8x
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

